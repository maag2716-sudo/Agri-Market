import 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      name: string;
      email: string;
      role: string;
      businessName?: string | null;
    };
  }
  interface User {
    role?: string;
    businessName?: string | null;
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    role?: string;
    id?: string;
    businessName?: string | null;
  }
}
