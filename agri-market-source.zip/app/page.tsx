import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { LandingContent } from '@/components/landing/landing-content';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';

export default async function Home() {
  const session = await auth();
  if (session?.user) {
    redirect(session.user.role === 'vendedor' ? '/vendedor' : '/cliente');
  }
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <LandingContent />
      <Footer />
    </div>
  );
}
