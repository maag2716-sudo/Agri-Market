import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { AuthForms } from '@/components/auth/auth-forms';

export default async function AuthPage() {
  const session = await auth();
  if (session?.user) {
    redirect(session.user.role === 'vendedor' ? '/vendedor' : '/cliente');
  }
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1 flex items-center justify-center py-10 px-4">
        <AuthForms />
      </main>
      <Footer />
    </div>
  );
}
