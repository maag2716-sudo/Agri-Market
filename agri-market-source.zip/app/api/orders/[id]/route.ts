export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const { id } = await params;
  const { status } = await req.json();
  const order = await prisma.order.findUnique({ where: { id } });
  if (!order) return NextResponse.json({ error: 'No encontrado' }, { status: 404 });
  if (order.vendorId !== session.user.id && order.clientId !== session.user.id)
    return NextResponse.json({ error: 'No autorizado' }, { status: 403 });

  const updated = await prisma.order.update({ where: { id }, data: { status } });
  return NextResponse.json(updated);
}
