export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const isVendor = session.user.role === 'vendedor';
  const orders = await prisma.order.findMany({
    where: isVendor ? { vendorId: session.user.id } : { clientId: session.user.id },
    include: {
      items: { include: { product: true } },
      client: { select: { name: true, email: true, phone: true } },
      vendor: { select: { name: true, vendorProfile: { select: { businessName: true } } } },
    },
    orderBy: { createdAt: 'desc' },
  });
  return NextResponse.json(orders);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { vendorId, items, notes } = await req.json();
  if (!vendorId || !items?.length) return NextResponse.json({ error: 'Datos incompletos' }, { status: 400 });

  let total = 0;
  const orderItems: any[] = [];
  for (const item of items) {
    const product = await prisma.product.findUnique({ where: { id: item.productId } });
    if (!product) continue;
    const unitPrice = product.price;
    total += unitPrice * item.quantity;
    orderItems.push({ productId: item.productId, quantity: item.quantity, unitPrice });
  }

  const order = await prisma.order.create({
    data: {
      clientId: session.user.id,
      vendorId,
      totalAmount: total,
      notes: notes ?? '',
      items: { create: orderItems },
    },
    include: { items: { include: { product: true } } },
  });

  return NextResponse.json(order);
}
