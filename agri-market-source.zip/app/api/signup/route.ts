export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, name, role, phone, businessName, description, specialty, location } = body ?? {};

    if (!email || !password || !name) {
      return NextResponse.json({ error: 'Campos requeridos: nombre, email y contraseña' }, { status: 400 });
    }

    const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
    if (existing) {
      return NextResponse.json({ error: 'Ya existe una cuenta con este correo' }, { status: 409 });
    }

    const hash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase().trim(),
        passwordHash: hash,
        name,
        role: role === 'vendedor' ? 'vendedor' : 'cliente',
        phone: phone ?? '',
      },
    });

    if (role === 'vendedor') {
      await prisma.vendorProfile.create({
        data: {
          userId: user.id,
          businessName: businessName || name,
          description: description ?? '',
          specialty: specialty || 'Mercado General',
          location: location ?? '',
        },
      });
    }

    return NextResponse.json({ success: true, userId: user.id });
  } catch (err: any) {
    console.error('Signup error:', err);
    return NextResponse.json({ error: 'Error al crear la cuenta' }, { status: 500 });
  }
}
