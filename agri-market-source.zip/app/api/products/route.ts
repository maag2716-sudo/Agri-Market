export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const vendorId = url.searchParams.get('vendorId');
    const category = url.searchParams.get('category');
    const search = url.searchParams.get('search');

    const where: any = { isActive: true };
    if (vendorId) where.vendorId = vendorId;
    if (category && category !== 'todos') where.category = category;
    if (search) where.name = { contains: search, mode: 'insensitive' };

    const products = await prisma.product.findMany({
      where,
      include: { vendor: { select: { name: true, vendorProfile: { select: { businessName: true } } } } },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    return NextResponse.json(products);
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    if (session.user.role !== 'vendedor') return NextResponse.json({ error: 'Solo vendedores' }, { status: 403 });

    const body = await req.json();
    const product = await prisma.product.create({
      data: {
        vendorId: session.user.id,
        name: body.name,
        description: body.description ?? '',
        price: parseFloat(body.price) || 0,
        quantity: parseInt(body.quantity) || 0,
        category: body.category || 'general',
        imageUrl: body.imageUrl ?? null,
        imagePublic: body.imagePublic ?? true,
        unit: body.unit || 'lb',
      },
    });
    return NextResponse.json(product);
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Error al crear producto' }, { status: 500 });
  }
}
