export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const product = await prisma.product.findUnique({ where: { id }, include: { vendor: { include: { vendorProfile: true } } } });
  if (!product) return NextResponse.json({ error: 'No encontrado' }, { status: 404 });
  return NextResponse.json(product);
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const { id } = await params;
  const product = await prisma.product.findUnique({ where: { id } });
  if (!product || product.vendorId !== session.user.id) return NextResponse.json({ error: 'No autorizado' }, { status: 403 });

  const body = await req.json();
  const updated = await prisma.product.update({
    where: { id },
    data: {
      name: body.name ?? product.name,
      description: body.description ?? product.description,
      price: body.price !== undefined ? parseFloat(body.price) : product.price,
      quantity: body.quantity !== undefined ? parseInt(body.quantity) : product.quantity,
      category: body.category ?? product.category,
      imageUrl: body.imageUrl !== undefined ? body.imageUrl : product.imageUrl,
      imagePublic: body.imagePublic ?? product.imagePublic,
      unit: body.unit ?? product.unit,
      isActive: body.isActive ?? product.isActive,
    },
  });
  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const { id } = await params;
  const product = await prisma.product.findUnique({ where: { id } });
  if (!product || product.vendorId !== session.user.id) return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
  await prisma.product.update({ where: { id }, data: { isActive: false } });
  return NextResponse.json({ success: true });
}
