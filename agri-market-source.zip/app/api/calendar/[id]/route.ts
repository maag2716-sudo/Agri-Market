export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const { id } = await params;

  const event = await prisma.calendarEvent.findUnique({ where: { id } });
  if (!event) return NextResponse.json({ error: 'No encontrado' }, { status: 404 });
  if (event.proposerId !== session.user.id && event.participantId !== session.user.id)
    return NextResponse.json({ error: 'No autorizado' }, { status: 403 });

  const { status, proposedDate } = await req.json();
  const data: any = {};
  if (status) data.status = status;
  if (proposedDate) data.proposedDate = new Date(proposedDate);

  const updated = await prisma.calendarEvent.update({ where: { id }, data });
  return NextResponse.json(updated);
}
