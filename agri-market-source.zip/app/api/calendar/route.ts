export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const events = await prisma.calendarEvent.findMany({
    where: {
      OR: [
        { proposerId: session.user.id },
        { participantId: session.user.id },
      ],
    },
    include: {
      proposer: { select: { id: true, name: true } },
      participant: { select: { id: true, name: true } },
    },
    orderBy: { proposedDate: 'asc' },
  });
  return NextResponse.json(events);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { participantId, title, description, proposedDate, orderId } = await req.json();
  if (!participantId || !title || !proposedDate)
    return NextResponse.json({ error: 'Datos incompletos' }, { status: 400 });

  const event = await prisma.calendarEvent.create({
    data: {
      proposerId: session.user.id,
      participantId,
      title,
      description: description ?? '',
      proposedDate: new Date(proposedDate),
      orderId: orderId ?? null,
    },
  });
  return NextResponse.json(event);
}
