export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const { id } = await params;
  const { quantity } = await req.json();
  const item = await prisma.cartItem.findUnique({ where: { id } });
  if (!item || item.clientId !== session.user.id) return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
  const updated = await prisma.cartItem.update({ where: { id }, data: { quantity } });
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const { id } = await params;
  const item = await prisma.cartItem.findUnique({ where: { id } });
  if (!item || item.clientId !== session.user.id) return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
  await prisma.cartItem.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
