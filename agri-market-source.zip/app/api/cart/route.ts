export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const items = await prisma.cartItem.findMany({
    where: { clientId: session.user.id },
    include: {
      product: {
        include: { vendor: { select: { name: true, id: true, vendorProfile: { select: { businessName: true } } } } },
      },
    },
  });
  return NextResponse.json(items);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { productId, quantity } = await req.json();
  if (!productId) return NextResponse.json({ error: 'productId requerido' }, { status: 400 });

  const item = await prisma.cartItem.upsert({
    where: { clientId_productId: { clientId: session.user.id, productId } },
    update: { quantity: quantity || 1 },
    create: { clientId: session.user.id, productId, quantity: quantity || 1 },
  });
  return NextResponse.json(item);
}

export async function DELETE() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  await prisma.cartItem.deleteMany({ where: { clientId: session.user.id } });
  return NextResponse.json({ success: true });
}
