export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { generatePresignedUploadUrl } from '@/lib/s3';

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { fileName, contentType, isPublic } = await req.json();
  if (!fileName || !contentType) return NextResponse.json({ error: 'Datos incompletos' }, { status: 400 });

  const result = await generatePresignedUploadUrl(fileName, contentType, isPublic ?? true);
  return NextResponse.json(result);
}
