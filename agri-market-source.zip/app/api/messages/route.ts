export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const url = new URL(req.url);
  const contactId = url.searchParams.get('contactId');
  const after = url.searchParams.get('after');

  if (contactId) {
    // Get messages for a specific conversation
    const where: any = {
      OR: [
        { senderId: session.user.id, receiverId: contactId },
        { senderId: contactId, receiverId: session.user.id },
      ],
    };
    if (after) where.createdAt = { gt: new Date(after) };

    const messages = await prisma.message.findMany({
      where,
      orderBy: { createdAt: 'asc' },
      take: 200,
    });

    // Mark unread messages as read
    await prisma.message.updateMany({
      where: { senderId: contactId, receiverId: session.user.id, isRead: false },
      data: { isRead: true },
    });

    return NextResponse.json(messages);
  }

  // Get conversation list
  const sent = await prisma.message.findMany({
    where: { senderId: session.user.id },
    select: { receiverId: true },
    distinct: ['receiverId'],
  });
  const received = await prisma.message.findMany({
    where: { receiverId: session.user.id },
    select: { senderId: true },
    distinct: ['senderId'],
  });

  const contactIds = [...new Set([...sent.map((s: any) => s.receiverId), ...received.map((r: any) => r.senderId)])];
  if (contactIds.length === 0) return NextResponse.json([]);

  const contacts = await prisma.user.findMany({
    where: { id: { in: contactIds } },
    select: { id: true, name: true, role: true, vendorProfile: { select: { businessName: true, avatar: true } } },
  });

  const conversations = await Promise.all(
    contacts.map(async (contact: any) => {
      const lastMsg = await prisma.message.findFirst({
        where: {
          OR: [
            { senderId: session.user.id, receiverId: contact.id },
            { senderId: contact.id, receiverId: session.user.id },
          ],
        },
        orderBy: { createdAt: 'desc' },
      });
      const unread = await prisma.message.count({
        where: { senderId: contact.id, receiverId: session.user.id, isRead: false },
      });
      return {
        contact,
        lastMessage: lastMsg,
        unreadCount: unread,
      };
    })
  );

  conversations.sort((a: any, b: any) => {
    const aTime = a.lastMessage?.createdAt?.getTime?.() ?? 0;
    const bTime = b.lastMessage?.createdAt?.getTime?.() ?? 0;
    return bTime - aTime;
  });

  return NextResponse.json(conversations);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { receiverId, content, orderRef } = await req.json();
  if (!receiverId || !content) return NextResponse.json({ error: 'Datos incompletos' }, { status: 400 });

  const message = await prisma.message.create({
    data: {
      senderId: session.user.id,
      receiverId,
      content,
      orderRef: orderRef ?? null,
    },
  });
  return NextResponse.json(message);
}
