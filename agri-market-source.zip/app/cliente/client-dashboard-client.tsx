'use client';

import { DashboardShell } from '@/components/dashboard/dashboard-shell';
import { LayoutDashboard, Search, ShoppingCart, Package, MessageSquare, CalendarDays } from 'lucide-react';

const navItems = [
  { href: '/cliente', label: 'Panel Principal', icon: <LayoutDashboard className="w-5 h-5" /> },
  { href: '/cliente/explorar', label: 'Explorar Vendedores', icon: <Search className="w-5 h-5" /> },
  { href: '/cliente/carrito', label: 'Mi Carrito', icon: <ShoppingCart className="w-5 h-5" /> },
  { href: '/cliente/pedidos', label: 'Mis Pedidos', icon: <Package className="w-5 h-5" /> },
  { href: '/cliente/mensajes', label: 'Mensajes', icon: <MessageSquare className="w-5 h-5" /> },
  { href: '/cliente/calendario', label: 'Calendario', icon: <CalendarDays className="w-5 h-5" /> },
];

export function ClientDashboardClient({ children }: { children: React.ReactNode }) {
  return <DashboardShell navItems={navItems}>{children}</DashboardShell>;
}
