'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function CarritoPage() {
  const router = useRouter();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [ordering, setOrdering] = useState(false);

  const load = () => {
    fetch('/api/cart').then(r => r.json()).then(d => { setItems(d ?? []); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const updateQty = async (id: string, qty: number) => {
    if (qty < 1) { await removeItem(id); return; }
    await fetch(`/api/cart/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ quantity: qty }) });
    load();
  };

  const removeItem = async (id: string) => {
    await fetch(`/api/cart/${id}`, { method: 'DELETE' });
    toast.success('Eliminado del carrito');
    load();
  };

  // Group by vendor
  const groups = (items ?? []).reduce((acc: Record<string, any[]>, item: any) => {
    const vendorId = item?.product?.vendorId ?? 'unknown';
    if (!acc[vendorId]) acc[vendorId] = [];
    acc[vendorId].push(item);
    return acc;
  }, {} as Record<string, any[]>);

  const total = (items ?? []).reduce((sum: number, i: any) => sum + ((i?.product?.price ?? 0) * (i?.quantity ?? 0)), 0);

  const handleOrder = async (vendorId: string, vendorItems: any[]) => {
    setOrdering(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vendorId,
          items: vendorItems.map((i: any) => ({ productId: i?.product?.id, quantity: i?.quantity })),
        }),
      });
      if (res.ok) {
        // Remove ordered items from cart
        for (const i of vendorItems) {
          await fetch(`/api/cart/${i.id}`, { method: 'DELETE' });
        }
        toast.success('¡Pedido realizado! Coordínalo por chat con el vendedor.');
        load();
      } else toast.error('Error al crear pedido');
    } catch { toast.error('Error'); } finally { setOrdering(false); }
  };

  if (loading) return <div className="flex items-center justify-center h-64 text-muted-foreground">Cargando...</div>;

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="font-display text-2xl font-bold tracking-tight mb-6 flex items-center gap-2">
        <ShoppingCart className="w-6 h-6 text-primary" /> Mi Carrito
      </h1>

      {(items?.length ?? 0) === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <ShoppingCart className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p>Tu carrito está vacío</p>
          <Button variant="outline" className="mt-4" onClick={() => router.push('/cliente/explorar')}>Explorar Productos</Button>
        </div>
      ) : (
        <>
          {Object.entries(groups).map(([vendorId, vendorItems]: [string, any[]]) => {
            const vendorName = vendorItems?.[0]?.product?.vendor?.vendorProfile?.businessName ?? vendorItems?.[0]?.product?.vendor?.name ?? 'Vendedor';
            const subtotal = vendorItems.reduce((s: number, i: any) => s + ((i?.product?.price ?? 0) * (i?.quantity ?? 0)), 0);
            return (
              <motion.div key={vendorId} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-xl shadow-md p-5 mb-4">
                <h2 className="font-semibold mb-3">{vendorName}</h2>
                <div className="space-y-3">
                  {vendorItems.map((item: any) => (
                    <div key={item?.id} className="flex items-center gap-3">
                      <div className="w-16 h-16 rounded-lg bg-muted relative flex-shrink-0 overflow-hidden">
                        {item?.product?.imageUrl ? (
                          <Image src={item.product.imageUrl} alt={item?.product?.name ?? ''} fill className="object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-2xl">🌿</div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{item?.product?.name}</p>
                        <p className="text-sm text-primary font-semibold">${item?.product?.price?.toFixed?.(2) ?? '0.00'} / {item?.product?.unit ?? 'lb'}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <button onClick={() => updateQty(item.id, (item?.quantity ?? 1) - 1)} className="w-7 h-7 rounded bg-muted flex items-center justify-center hover:bg-muted/80">
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center text-sm font-medium">{item?.quantity ?? 1}</span>
                        <button onClick={() => updateQty(item.id, (item?.quantity ?? 1) + 1)} className="w-7 h-7 rounded bg-muted flex items-center justify-center hover:bg-muted/80">
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <p className="font-semibold text-sm w-16 text-right">${((item?.product?.price ?? 0) * (item?.quantity ?? 0)).toFixed(2)}</p>
                      <button onClick={() => removeItem(item.id)} className="text-destructive hover:text-destructive/80"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                </div>
                <div className="border-t mt-3 pt-3 flex items-center justify-between">
                  <span className="font-semibold">Subtotal: <span className="text-primary">${subtotal.toFixed(2)}</span></span>
                  <Button onClick={() => handleOrder(vendorId, vendorItems)} loading={ordering}>
                    <ShoppingBag className="w-4 h-4 mr-1" />Confirmar Pedido
                  </Button>
                </div>
              </motion.div>
            );
          })}
          <div className="bg-primary/5 rounded-xl p-4 text-right">
            <span className="text-lg font-bold">Total General: <span className="text-primary">${total.toFixed(2)}</span></span>
          </div>
        </>
      )}
    </div>
  );
}
