'use client';

import { CalendarView } from '@/components/calendar/calendar-view';

export default function CalendarioClientPage() {
  return <CalendarView />;
}
