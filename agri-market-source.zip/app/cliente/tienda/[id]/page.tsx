'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useSession } from 'next-auth/react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { CATEGORIES } from '@/lib/categories';
import { ShoppingCart, MapPin, MessageSquare, ArrowLeft, Plus, Minus } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function TiendaVendedorPage() {
  const params = useParams();
  const { data: session } = useSession();
  const [vendor, setVendor] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const id = params?.id as string;
    if (!id) return;
    fetch(`/api/vendors/${id}`)
      .then(r => r.json())
      .then(d => { setVendor(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [params?.id]);

  const addToCart = async (productId: string) => {
    try {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, quantity: 1 }),
      });
      if (res.ok) toast.success('Agregado al carrito');
      else toast.error('Error');
    } catch { toast.error('Error'); }
  };

  const startChat = async () => {
    try {
      await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiverId: vendor?.userId, content: `¡Hola! Me interesa tu tienda ${vendor?.businessName}` }),
      });
      toast.success('Mensaje enviado. Ve a Mensajes para continuar la conversación.');
    } catch { toast.error('Error'); }
  };

  if (loading) return <div className="flex items-center justify-center h-64 text-muted-foreground">Cargando...</div>;
  if (!vendor) return <div className="text-center py-16 text-muted-foreground">Vendedor no encontrado</div>;

  const products = vendor?.products ?? [];
  const categorizedProducts = CATEGORIES.map(cat => ({
    ...cat,
    items: products.filter((p: any) => p?.category === cat.id),
  })).filter(c => c.items.length > 0);

  return (
    <div className="max-w-[1200px] mx-auto">
      <Link href="/cliente/explorar" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="w-4 h-4" />Volver a Explorar
      </Link>

      {/* Banner */}
      <div className="relative h-48 md:h-64 rounded-xl overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 mb-6">
        {vendor?.coverImage && <Image src={vendor.coverImage} alt={vendor?.businessName ?? ''} fill className="object-cover" />}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <h1 className="text-white font-display text-3xl font-bold">{vendor?.businessName ?? 'Tienda'}</h1>
          <div className="flex items-center gap-4 mt-2 text-white/80 text-sm">
            <span className="flex items-center gap-1">{CATEGORIES.find(c => c.name === vendor?.specialty)?.emoji} {vendor?.specialty}</span>
            {vendor?.location && <span className="flex items-center gap-1"><MapPin className="w-4 h-4" />{vendor.location}</span>}
          </div>
        </div>
      </div>

      {/* Description & actions */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="flex-1">
          {vendor?.description && <p className="text-muted-foreground">{vendor.description}</p>}
        </div>
        <Button onClick={startChat} variant="outline">
          <MessageSquare className="w-4 h-4 mr-1" />Contactar Vendedor
        </Button>
      </div>

      {/* Products by category */}
      {categorizedProducts.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">Este vendedor aún no tiene productos publicados</div>
      ) : (
        categorizedProducts.map(cat => (
          <div key={cat.id} className="mb-8">
            <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">{cat.emoji} {cat.name}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {cat.items.map((p: any, i: number) => (
                <motion.div key={p?.id ?? i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                  className="bg-card rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all">
                  <div className="aspect-video relative bg-muted">
                    {p?.imageUrl ? (
                      <Image src={p.imageUrl} alt={p?.name ?? 'Producto'} fill className="object-cover" />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center text-4xl">{cat.emoji}</div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold">{p?.name}</h3>
                    {p?.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{p.description}</p>}
                    <div className="flex items-center justify-between mt-3">
                      <div>
                        <span className="text-lg font-bold text-primary">${p?.price?.toFixed?.(2) ?? '0.00'}</span>
                        <span className="text-xs text-muted-foreground ml-1">/ {p?.unit ?? 'lb'}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{p?.quantity ?? 0} disponibles</span>
                    </div>
                    <Button size="sm" className="w-full mt-3" onClick={() => addToCart(p.id)} disabled={(p?.quantity ?? 0) === 0}>
                      <ShoppingCart className="w-4 h-4 mr-1" />{(p?.quantity ?? 0) === 0 ? 'Agotado' : 'Agregar al Carrito'}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
