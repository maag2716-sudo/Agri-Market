import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { ClientDashboardContent } from './client-dashboard-content';

export const dynamic = 'force-dynamic';

export default async function ClientDashboard() {
  const session = await auth();
  if (!session?.user?.id) redirect('/auth');

  const [orderCount, cartCount, unreadMessages] = await Promise.all([
    prisma.order.count({ where: { clientId: session.user.id } }),
    prisma.cartItem.count({ where: { clientId: session.user.id } }),
    prisma.message.count({ where: { receiverId: session.user.id, isRead: false } }),
  ]);

  return (
    <ClientDashboardContent
      userName={session.user.name}
      stats={{ orders: orderCount, cart: cartCount, messages: unreadMessages }}
    />
  );
}
