'use client';

import { useState, useEffect } from 'react';
import { Package, Clock, CheckCircle, Truck, XCircle, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';

const STATUS_MAP: Record<string, { label: string; icon: any; color: string }> = {
  pendiente: { label: 'Pendiente', icon: Clock, color: 'text-yellow-600 bg-yellow-100' },
  confirmado: { label: 'Confirmado', icon: CheckCircle, color: 'text-blue-600 bg-blue-100' },
  entregado: { label: 'Entregado', icon: Truck, color: 'text-green-600 bg-green-100' },
  cancelado: { label: 'Cancelado', icon: XCircle, color: 'text-red-600 bg-red-100' },
};

export default function PedidosClientPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    fetch('/api/orders').then(r => r.json()).then(d => { setOrders(d ?? []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const shareToChat = async (order: any) => {
    try {
      const itemList = (order?.items ?? []).map((i: any) => `${i?.product?.name} x${i?.quantity}`).join(', ');
      await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          receiverId: order?.vendorId,
          content: `📦 Detalles del pedido #${(order?.id ?? '').slice(-6)}:\n${itemList}\nTotal: $${order?.totalAmount?.toFixed?.(2) ?? '0.00'}`,
          orderRef: order?.id,
        }),
      });
      toast.success('Detalles del pedido enviados al chat');
    } catch { toast.error('Error'); }
  };

  if (loading) return <div className="flex items-center justify-center h-64 text-muted-foreground">Cargando...</div>;

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="font-display text-2xl font-bold tracking-tight mb-6 flex items-center gap-2">
        <Package className="w-6 h-6 text-primary" /> Mis Pedidos
      </h1>

      {(orders?.length ?? 0) === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Package className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p>Aún no tienes pedidos</p>
        </div>
      ) : (
        <div className="space-y-4">
          {(orders ?? []).map((o: any, i: number) => {
            const st = STATUS_MAP[o?.status] ?? STATUS_MAP.pendiente;
            const StIcon = st.icon;
            return (
              <motion.div key={o?.id ?? i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="bg-card rounded-xl p-5 shadow-md">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <div>
                    <p className="font-semibold">Pedido #{(o?.id ?? '').slice(-6)}</p>
                    <p className="text-sm text-muted-foreground">Vendedor: {o?.vendor?.vendorProfile?.businessName ?? o?.vendor?.name ?? 'Vendedor'}</p>
                  </div>
                  <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${st.color}`}>
                    <StIcon className="w-3 h-3" />{st.label}
                  </div>
                </div>
                <div className="space-y-1 mb-3">
                  {(o?.items ?? []).map((item: any) => (
                    <div key={item?.id} className="flex justify-between text-sm">
                      <span>{item?.product?.name ?? 'Producto'} x{item?.quantity}</span>
                      <span>${((item?.unitPrice ?? 0) * (item?.quantity ?? 0)).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="border-t pt-1 flex justify-between font-semibold">
                    <span>Total</span><span className="text-primary">${o?.totalAmount?.toFixed?.(2) ?? '0.00'}</span>
                  </div>
                </div>
                <Button size="sm" variant="outline" onClick={() => shareToChat(o)}>
                  <MessageSquare className="w-3 h-3 mr-1" />Compartir en Chat
                </Button>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
