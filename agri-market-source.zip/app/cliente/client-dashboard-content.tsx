'use client';

import { motion } from 'framer-motion';
import { ShoppingCart, Package, MessageSquare, Search } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

interface Props {
  userName: string;
  stats: { orders: number; cart: number; messages: number };
}

export function ClientDashboardContent({ userName, stats }: Props) {
  const statCards = [
    { label: 'En Carrito', value: stats.cart, icon: ShoppingCart, color: 'bg-primary/10 text-primary', href: '/cliente/carrito' },
    { label: 'Pedidos', value: stats.orders, icon: Package, color: 'bg-accent/10 text-accent', href: '/cliente/pedidos' },
    { label: 'Mensajes sin leer', value: stats.messages, icon: MessageSquare, color: 'bg-destructive/10 text-destructive', href: '/cliente/mensajes' },
  ];

  return (
    <div className="max-w-[1200px] mx-auto">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="font-display text-3xl font-bold tracking-tight">Hola, {userName} 👋</h1>
        <p className="text-muted-foreground mt-1">Encuentra los mejores productos frescos del campo</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {statCards.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <Link href={s.href}>
              <div className="bg-card rounded-xl p-5 shadow-md hover:shadow-lg transition-all cursor-pointer">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${s.color}`}>
                  <s.icon className="w-5 h-5" />
                </div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-sm text-muted-foreground">{s.label}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <Link href="/cliente/explorar">
          <Button size="lg" className="w-full sm:w-auto">
            <Search className="w-5 h-5 mr-2" />Explorar Vendedores y Productos
          </Button>
        </Link>
      </motion.div>
    </div>
  );
}
