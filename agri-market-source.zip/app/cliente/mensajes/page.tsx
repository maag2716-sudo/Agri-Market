'use client';

import { ChatInterface } from '@/components/chat/chat-interface';

export default function MensajesClientPage() {
  return <ChatInterface />;
}
