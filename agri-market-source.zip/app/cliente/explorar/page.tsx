'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { CATEGORIES } from '@/lib/categories';
import { Search, MapPin, Star, Package, Store } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ExplorarPage() {
  const [vendors, setVendors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [specialty, setSpecialty] = useState('todos');

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (specialty !== 'todos') params.set('specialty', specialty);
    fetch(`/api/vendors?${params}`)
      .then(r => r.json())
      .then(d => { setVendors(d ?? []); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, [specialty]);

  return (
    <div className="max-w-[1200px] mx-auto">
      <h1 className="font-display text-2xl font-bold tracking-tight mb-6 flex items-center gap-2">
        <Store className="w-6 h-6 text-primary" /> Explorar Vendedores
      </h1>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Buscar vendedor..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10"
            onKeyDown={e => e.key === 'Enter' && load()} />
        </div>
        <select
          className="h-10 rounded-md border border-input bg-background px-3 text-sm min-w-[200px]"
          value={specialty}
          onChange={e => setSpecialty(e.target.value)}
        >
          <option value="todos">Todas las categorías</option>
          {CATEGORIES.map(c => <option key={c.id} value={c.name}>{c.emoji} {c.name}</option>)}
        </select>
        <Button onClick={load}><Search className="w-4 h-4 mr-1" />Buscar</Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40 text-muted-foreground">Cargando vendedores...</div>
      ) : (vendors?.length ?? 0) === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Store className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p>No se encontraron vendedores</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(vendors ?? []).map((v: any, i: number) => (
            <motion.div key={v?.id ?? i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Link href={`/cliente/tienda/${v?.userId}`}>
                <div className="bg-card rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all cursor-pointer group">
                  <div className="h-32 relative bg-gradient-to-br from-primary/20 to-accent/20">
                    {v?.coverImage && <Image src={v.coverImage} alt={v?.businessName ?? ''} fill className="object-cover" />}
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                      <h3 className="text-white font-semibold">{v?.businessName ?? 'Vendedor'}</h3>
                    </div>
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      {CATEGORIES.find(c => c.name === v?.specialty)?.emoji ?? '🌿'} {v?.specialty ?? 'Mercado General'}
                    </p>
                    {v?.location && <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="w-3 h-3" />{v.location}</p>}
                    <div className="flex items-center justify-between mt-3">
                      <span className="text-xs text-muted-foreground flex items-center gap-1"><Package className="w-3 h-3" />{v?.productCount ?? 0} productos</span>
                      {(v?.isFeatured) && <span className="text-xs bg-accent/20 text-accent px-2 py-0.5 rounded-full flex items-center gap-1"><Star className="w-3 h-3" />Destacado</span>}
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
