import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { ClientDashboardClient } from './client-dashboard-client';

export default async function ClientLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user) redirect('/auth');
  if (session.user.role !== 'vendedor' && session.user.role !== 'cliente') redirect('/auth');
  if (session.user.role === 'vendedor') redirect('/vendedor');
  return <ClientDashboardClient>{children}</ClientDashboardClient>;
}
