'use client';

import { motion } from 'framer-motion';
import { Package, ShoppingBag, MessageSquare, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

interface Props {
  userName: string;
  businessName: string;
  stats: { products: number; orders: number; messages: number };
}

export function VendorDashboardContent({ userName, businessName, stats }: Props) {
  const statCards = [
    { label: 'Productos', value: stats.products, icon: Package, color: 'bg-primary/10 text-primary', href: '/vendedor/productos' },
    { label: 'Pedidos', value: stats.orders, icon: ShoppingBag, color: 'bg-accent/10 text-accent', href: '/vendedor/pedidos' },
    { label: 'Mensajes sin leer', value: stats.messages, icon: MessageSquare, color: 'bg-destructive/10 text-destructive', href: '/vendedor/mensajes' },
  ];

  return (
    <div className="max-w-[1200px] mx-auto">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="font-display text-3xl font-bold tracking-tight">Hola, {userName} 👋</h1>
        <p className="text-muted-foreground mt-1">Bienvenido a <span className="font-semibold text-primary">{businessName}</span></p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {statCards.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Link href={s.href}>
              <div className="bg-card rounded-xl p-5 shadow-md hover:shadow-lg transition-all cursor-pointer">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${s.color}`}>
                    <s.icon className="w-5 h-5" />
                  </div>
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                </div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-sm text-muted-foreground">{s.label}</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="bg-card rounded-xl p-6 shadow-md">
          <h2 className="font-semibold text-lg mb-3">Acciones Rápidas</h2>
          <div className="space-y-2">
            <Link href="/vendedor/productos"><Button className="w-full justify-start" variant="outline"><Package className="w-4 h-4 mr-2" />Agregar Producto</Button></Link>
            <Link href="/vendedor/pedidos"><Button className="w-full justify-start" variant="outline"><ShoppingBag className="w-4 h-4 mr-2" />Ver Pedidos</Button></Link>
            <Link href="/vendedor/mensajes"><Button className="w-full justify-start" variant="outline"><MessageSquare className="w-4 h-4 mr-2" />Ver Mensajes</Button></Link>
          </div>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="bg-card rounded-xl p-6 shadow-md">
          <h2 className="font-semibold text-lg mb-3">Consejo del Día</h2>
          <p className="text-sm text-muted-foreground">
            🌿 Mantén tus productos actualizados con fotos atractivas y descripciones
            detalladas. Los compradores valoran la transparencia sobre el origen y
            frescura de los productos.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
