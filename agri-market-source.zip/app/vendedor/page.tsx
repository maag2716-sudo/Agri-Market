import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { VendorDashboardContent } from './vendor-dashboard-content';

export const dynamic = 'force-dynamic';

export default async function VendorDashboard() {
  const session = await auth();
  if (!session?.user?.id) redirect('/auth');

  const [productCount, orderCount, unreadMessages, profile] = await Promise.all([
    prisma.product.count({ where: { vendorId: session.user.id, isActive: true } }),
    prisma.order.count({ where: { vendorId: session.user.id } }),
    prisma.message.count({ where: { receiverId: session.user.id, isRead: false } }),
    prisma.vendorProfile.findUnique({ where: { userId: session.user.id } }),
  ]);

  return (
    <VendorDashboardContent
      userName={session.user.name}
      businessName={profile?.businessName ?? 'Tu Negocio'}
      stats={{ products: productCount, orders: orderCount, messages: unreadMessages }}
    />
  );
}
