import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { VendorDashboardClient } from './vendor-dashboard-client';

export default async function VendorLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user) redirect('/auth');
  if (session.user.role !== 'vendedor') redirect('/cliente');
  return <VendorDashboardClient>{children}</VendorDashboardClient>;
}
