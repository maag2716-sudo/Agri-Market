'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ShoppingBag, Clock, CheckCircle, Truck, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const STATUS_MAP: Record<string, { label: string; icon: any; color: string }> = {
  pendiente: { label: 'Pendiente', icon: Clock, color: 'text-yellow-600 bg-yellow-100' },
  confirmado: { label: 'Confirmado', icon: CheckCircle, color: 'text-blue-600 bg-blue-100' },
  entregado: { label: 'Entregado', icon: Truck, color: 'text-green-600 bg-green-100' },
  cancelado: { label: 'Cancelado', icon: XCircle, color: 'text-red-600 bg-red-100' },
};

export default function PedidosVendorPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    fetch('/api/orders').then(r => r.json()).then(d => { setOrders(d ?? []); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const updateStatus = async (id: string, status: string) => {
    const res = await fetch(`/api/orders/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (res.ok) { toast.success('Estado actualizado'); load(); }
  };

  if (loading) return <div className="flex items-center justify-center h-64 text-muted-foreground">Cargando...</div>;

  return (
    <div className="max-w-[1200px] mx-auto">
      <h1 className="font-display text-2xl font-bold tracking-tight mb-6 flex items-center gap-2">
        <ShoppingBag className="w-6 h-6 text-primary" /> Pedidos Recibidos
      </h1>

      {(orders?.length ?? 0) === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <ShoppingBag className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p>No tienes pedidos aún.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {(orders ?? []).map((o: any, i: number) => {
            const st = STATUS_MAP[o?.status] ?? STATUS_MAP.pendiente;
            const StIcon = st.icon;
            return (
              <motion.div key={o?.id ?? i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="bg-card rounded-xl p-5 shadow-md">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                  <div>
                    <p className="font-semibold">Pedido #{(o?.id ?? '').slice(-6)}</p>
                    <p className="text-sm text-muted-foreground">Cliente: {o?.client?.name ?? 'Desconocido'} • {o?.client?.phone ?? ''}</p>
                  </div>
                  <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${st.color}`}>
                    <StIcon className="w-3 h-3" />{st.label}
                  </div>
                </div>
                <div className="space-y-1 mb-3">
                  {(o?.items ?? []).map((item: any) => (
                    <div key={item?.id} className="flex justify-between text-sm">
                      <span>{item?.product?.name ?? 'Producto'} x{item?.quantity}</span>
                      <span className="font-medium">${(item?.unitPrice * item?.quantity)?.toFixed?.(2) ?? '0.00'}</span>
                    </div>
                  ))}
                  <div className="border-t pt-1 flex justify-between font-semibold">
                    <span>Total</span><span className="text-primary">${o?.totalAmount?.toFixed?.(2) ?? '0.00'}</span>
                  </div>
                </div>
                {o?.notes && <p className="text-sm text-muted-foreground mb-3">Nota: {o.notes}</p>}
                <div className="flex gap-2 flex-wrap">
                  {o?.status === 'pendiente' && (
                    <>
                      <Button size="sm" onClick={() => updateStatus(o.id, 'confirmado')}>Confirmar</Button>
                      <Button size="sm" variant="destructive" onClick={() => updateStatus(o.id, 'cancelado')}>Cancelar</Button>
                    </>
                  )}
                  {o?.status === 'confirmado' && (
                    <Button size="sm" onClick={() => updateStatus(o.id, 'entregado')}><Truck className="w-3 h-3 mr-1" />Marcar Entregado</Button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
