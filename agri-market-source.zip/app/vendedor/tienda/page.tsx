'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ImageUpload } from '@/components/image-upload';
import { CATEGORIES } from '@/lib/categories';
import { Save, Store, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function TiendaPage() {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    if (!session?.user?.id) return;
    fetch(`/api/vendors/${session.user.id}`)
      .then(r => r.json())
      .then(d => { setProfile(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [session?.user?.id]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch(`/api/vendors/${session?.user?.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName: profile?.businessName,
          description: profile?.description,
          specialty: profile?.specialty,
          location: profile?.location,
          coverImage: profile?.coverImage,
          avatar: profile?.avatar,
        }),
      });
      if (res.ok) toast.success('Tienda actualizada');
      else toast.error('Error al guardar');
    } catch {
      toast.error('Error al guardar');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-pulse text-muted-foreground">Cargando...</div></div>;

  return (
    <div className="max-w-3xl mx-auto">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display text-2xl font-bold tracking-tight mb-6 flex items-center gap-2">
          <Store className="w-6 h-6 text-primary" /> Mi Tienda
        </h1>

        <div className="space-y-6">
          <div>
            <Label className="text-base font-semibold">Portada del Negocio</Label>
            <ImageUpload
              value={profile?.coverImage}
              onChange={(url) => setProfile({ ...(profile ?? {}), coverImage: url })}
              className="mt-2"
              aspectRatio="aspect-[3/1]"
            />
          </div>

          <div>
            <Label className="text-base font-semibold">Avatar / Logo</Label>
            <ImageUpload
              value={profile?.avatar}
              onChange={(url) => setProfile({ ...(profile ?? {}), avatar: url })}
              className="mt-2 w-32 h-32"
              aspectRatio="aspect-square"
            />
          </div>

          <div>
            <Label>Nombre del Negocio</Label>
            <Input value={profile?.businessName ?? ''} onChange={e => setProfile({ ...(profile ?? {}), businessName: e.target.value })} className="mt-1" />
          </div>

          <div>
            <Label>Descripción</Label>
            <textarea
              className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm mt-1"
              value={profile?.description ?? ''}
              onChange={e => setProfile({ ...(profile ?? {}), description: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label>Especialidad</Label>
              <select
                className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm mt-1"
                value={profile?.specialty ?? 'Mercado General'}
                onChange={e => setProfile({ ...(profile ?? {}), specialty: e.target.value })}
              >
                {CATEGORIES.map(c => <option key={c.id} value={c.name}>{c.emoji} {c.name}</option>)}
              </select>
            </div>
            <div>
              <Label>Ubicación</Label>
              <div className="relative mt-1">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input value={profile?.location ?? ''} onChange={e => setProfile({ ...(profile ?? {}), location: e.target.value })} className="pl-10" />
              </div>
            </div>
          </div>

          <Button onClick={handleSave} loading={saving} className="w-full sm:w-auto">
            <Save className="w-4 h-4 mr-2" />Guardar Cambios
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
