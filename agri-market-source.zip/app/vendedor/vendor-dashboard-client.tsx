'use client';

import { DashboardShell } from '@/components/dashboard/dashboard-shell';
import { LayoutDashboard, Package, Store, MessageSquare, CalendarDays, ShoppingBag } from 'lucide-react';

const navItems = [
  { href: '/vendedor', label: 'Panel Principal', icon: <LayoutDashboard className="w-5 h-5" /> },
  { href: '/vendedor/tienda', label: 'Mi Tienda', icon: <Store className="w-5 h-5" /> },
  { href: '/vendedor/productos', label: 'Productos', icon: <Package className="w-5 h-5" /> },
  { href: '/vendedor/pedidos', label: 'Pedidos', icon: <ShoppingBag className="w-5 h-5" /> },
  { href: '/vendedor/mensajes', label: 'Mensajes', icon: <MessageSquare className="w-5 h-5" /> },
  { href: '/vendedor/calendario', label: 'Calendario', icon: <CalendarDays className="w-5 h-5" /> },
];

export function VendorDashboardClient({ children }: { children: React.ReactNode }) {
  return <DashboardShell navItems={navItems}>{children}</DashboardShell>;
}
