'use client';

import { ChatInterface } from '@/components/chat/chat-interface';

export default function MensajesVendorPage() {
  return <ChatInterface />;
}
