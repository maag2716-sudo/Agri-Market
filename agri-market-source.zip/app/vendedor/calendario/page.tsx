'use client';

import { CalendarView } from '@/components/calendar/calendar-view';

export default function CalendarioVendorPage() {
  return <CalendarView />;
}
