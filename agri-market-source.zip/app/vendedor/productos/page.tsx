'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ImageUpload } from '@/components/image-upload';
import { CATEGORIES } from '@/lib/categories';
import { Plus, Edit2, Trash2, Package, X, Save } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';

export default function ProductosPage() {
  const { data: session } = useSession();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ name: '', description: '', price: '', quantity: '', category: 'verduras', unit: 'lb', imageUrl: '' as string | null });

  const loadProducts = () => {
    if (!session?.user?.id) return;
    fetch(`/api/products?vendorId=${session.user.id}`)
      .then(r => r.json())
      .then(d => { setProducts(d ?? []); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { loadProducts(); }, [session?.user?.id]);

  const resetForm = () => {
    setForm({ name: '', description: '', price: '', quantity: '', category: 'verduras', unit: 'lb', imageUrl: '' });
    setEditing(null);
    setShowForm(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editing ? `/api/products/${editing.id}` : '/api/products';
      const method = editing ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, imageUrl: form.imageUrl || null }),
      });
      if (res.ok) {
        toast.success(editing ? 'Producto actualizado' : 'Producto creado');
        resetForm();
        loadProducts();
      } else toast.error('Error al guardar');
    } catch { toast.error('Error'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar este producto?')) return;
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success('Producto eliminado'); loadProducts(); }
  };

  const startEdit = (p: any) => {
    setForm({ name: p.name, description: p.description ?? '', price: String(p.price), quantity: String(p.quantity), category: p.category, unit: p.unit ?? 'lb', imageUrl: p.imageUrl });
    setEditing(p);
    setShowForm(true);
  };

  const getCatName = (id: string) => CATEGORIES.find(c => c.id === id)?.name ?? id;

  if (loading) return <div className="flex items-center justify-center h-64 text-muted-foreground">Cargando...</div>;

  return (
    <div className="max-w-[1200px] mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
          <Package className="w-6 h-6 text-primary" /> Mis Productos
        </h1>
        <Button onClick={() => { resetForm(); setShowForm(true); }}><Plus className="w-4 h-4 mr-1" />Nuevo</Button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-6">
            <form onSubmit={handleSubmit} className="bg-card rounded-xl p-6 shadow-md space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold text-lg">{editing ? 'Editar Producto' : 'Nuevo Producto'}</h2>
                <button type="button" onClick={resetForm}><X className="w-5 h-5" /></button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>Nombre del producto</Label>
                  <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="mt-1" required />
                </div>
                <div>
                  <Label>Categoría</Label>
                  <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm mt-1" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                    {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <Label>Descripción</Label>
                <textarea className="w-full min-h-[60px] rounded-md border border-input bg-background px-3 py-2 text-sm mt-1" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div><Label>Precio ($)</Label><Input type="number" step="0.01" min="0" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} className="mt-1" required /></div>
                <div><Label>Cantidad</Label><Input type="number" min="0" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} className="mt-1" required /></div>
                <div><Label>Unidad</Label>
                  <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm mt-1" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })}>
                    <option value="lb">Libra</option><option value="kg">Kilogramo</option><option value="unidad">Unidad</option><option value="docena">Docena</option><option value="manojo">Manojo</option>
                  </select>
                </div>
              </div>
              <div>
                <Label>Imagen del producto</Label>
                <ImageUpload value={form.imageUrl} onChange={(url) => setForm({ ...form, imageUrl: url })} className="mt-2" />
              </div>
              <Button type="submit"><Save className="w-4 h-4 mr-1" />{editing ? 'Actualizar' : 'Crear'} Producto</Button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {(products?.length ?? 0) === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Package className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p>Aún no tienes productos. ¡Agrega tu primer producto!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(products ?? []).map((p: any, i: number) => (
            <motion.div key={p?.id ?? i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-card rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video relative bg-muted">
                {p?.imageUrl ? (
                  <Image src={p.imageUrl} alt={p?.name ?? 'Producto'} fill className="object-cover" />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-4xl">{CATEGORIES.find(c => c.id === p?.category)?.emoji ?? '🌿'}</div>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold truncate">{p?.name}</h3>
                <p className="text-xs text-muted-foreground">{getCatName(p?.category)}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-lg font-bold text-primary">${p?.price?.toFixed?.(2) ?? '0.00'}</span>
                  <span className="text-sm text-muted-foreground">{p?.quantity ?? 0} {p?.unit ?? 'lb'}</span>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button size="sm" variant="outline" onClick={() => startEdit(p)} className="flex-1"><Edit2 className="w-3 h-3 mr-1" />Editar</Button>
                  <Button size="sm" variant="destructive" onClick={() => handleDelete(p?.id)}><Trash2 className="w-3 h-3" /></Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
